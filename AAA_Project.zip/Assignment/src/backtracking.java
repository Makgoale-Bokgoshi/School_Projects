import java.sql.SQLException;
import java.util.*;

public class backtracking {
	
	
 private static int emptyField = 0;
 private static boolean [][] row = new boolean[9][10];	
 private static boolean [][] col = new boolean[9][10];
 private static boolean [][] box = new boolean[9][10];
 private static int [][] partialSudoku;
 private static int [][] sudoku = new int[9][9];
 

    public backtracking(int [][] partialSudoku ) {
    	this.partialSudoku = partialSudoku;
     initialize();
    }
    double StartTime= System.currentTimeMillis();
    private void initialize() {
    	              for (int boxNumber = 0; boxNumber < 9; boxNumber++) {
    	            	  for (int number = 1; number < 10; number++) {
    	            		  this.box[boxNumber][number] = false;
    	                  }
    	          }
    	              for (int row = 0; row < 9; row++) {
    	                  for (int column = 0; column < 9; column++) {
    	                	 this.row[row][column + 1] = false;
    	                   	this.col[row][column + 1] = false;
    	                    this.sudoku[row][column] = emptyField;
    	    
    	                          if (! isEmptyField(partialSudoku[row][column])) {
    	                        this.sudoku[row][column] = partialSudoku[row][column];
    	                        this.row[row][partialSudoku[row][column]] = true;
    	                  this.col[column][partialSudoku[row][column]] = true;
    	                        this.box[getBoxNumber(row, column)][partialSudoku[row][column]] = true;
    	                    }
    	                 }
    	                }
    	      }
    
    private static boolean isEmptyField(int number) {
     return number <= 0 || number > 9;
    }
  
  private boolean numberCanBePlaced(int row, int column, int number) {
	      return  (partialSudoku[row][column] == number || isEmptyField(partialSudoku[row][column])
	               && 	!this.row[row][number]
	            	&&		! this.col[column][number]
	            		&& ! this.box[getBoxNumber(row, column)][number]);
	  } 		 

  
  public boolean SolveSudoku(int counter){
        int row = counter/9; 
        int col = counter%9;
        
      for (int number = 1 ; number < 10; number++){
        if (numberCanBePlaced(row, col, number) ) { 
        	boolean r = this.row[row][number];
        	boolean c = this.col[col][number];
        	boolean b = this.box[getBoxNumber(row, col)][number];
        	this.sudoku[row][col]= number;
        	this.row[row][number] = true;
        	this.col[col][number] = true;
        	this.box[getBoxNumber(row, col)][number] = true;
        if (counter < 80) {
        	if ( SolveSudoku(counter + 1) ) {
         return true;	
        	}
       
        else{
        		
        		 	this.sudoku[row][col] = partialSudoku[row][col];
        		 	this.row[row][number] = r;
        		 	this.col[col][number] = c;
        		 	this.box[getBoxNumber(row, col)][number] = b;
        		
        }	
        	}
    		   else {
            return true;     
            }
         }
       }   
        
        return false; // this triggers backtracking
    }

  private static int getBoxNumber(int row, int column) {
	   return 3 * (row / 3) + (column / 3);
       }

  double EndTime= System.currentTimeMillis();

  
public static void main(String[] args) {
	
	ReadIn obj=new ReadIn();
	try {
		obj.Reading();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
   
}}
  
  
  



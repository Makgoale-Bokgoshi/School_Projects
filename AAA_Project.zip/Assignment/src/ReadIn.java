/**
 * 
 */

/**
 * @author student
 *
 */
import java.sql.*;
import java.util.*;
public class ReadIn {
	
	 DBClass db = new DBClass();
	 
	    Connection con = db.dbConnector();
	    Statement stmt = null;
	   int [][] arr = new int [9][9];
	   
	   
	   
	   String  querystr = ("SELECT GRID FROM SAMPLES");
	   int Count=1;
	   
	 public void Reading() throws SQLException{
	    try{
	    	String  grid = db.query(querystr).trim();
	    //	System.out.println(grid);
	    	String grids[]= grid.split("\n");
	    //	System.out.println("Check :"+grids[grids.length-1]+"\n"+grids.length);
	    	for(int l=0;l<grids.length;l++){
	    		//System.out.println("Check :"+grids[l]+"\n"+l);
	    		int Counter=0;
	    		grids[l]=grids[l].trim();
	    		//System.out.print(grids[l]);
	    	// 	System.out.println();
	    	   	String Line[] =grids[l].split(";");
	    	
	    	   	for(int i=0; i<9; i++){
	    		Line[i] = Line[i].trim();
	    	   		
	    	//	System.out.println("Length   "+Line[i].length());
	    	   		String Number[]= Line[i].split(",");
	    	   		for(int j=0;j<9;j++){
	    	   			arr [i][j]= Integer.parseInt(Number[j]);
	    	   			if(arr[i][j]==0){
	    	   				Counter++;
	    	   			}
	    	   			//BT.SolveSudoku(0);
	    	   			//System.out.println("This is the arr entry"+" " +arr [i][j]);
	    	   			
	    	   			}
	    	   	}
	    	   	System.out.println("GRID  "+ Count);
	    	   	
	    	   	backtracking BT = new backtracking(arr);
	    	    if (BT.SolveSudoku(0) == true){
	    	    	
	    	    	double Startnano=System.nanoTime();
	    	    	double StartTime= System.currentTimeMillis();
	    	    	BT.SolveSudoku(0);
	    	    	double EndTime= System.currentTimeMillis();
	    	    			double EndNano=System.nanoTime();
	    	    	Count= Count+1;
	    	     //   System.out.println("solution found");
	    	    	System.out.print("Time: ");
	    	    	System.out.println(EndNano-Startnano +"ns");
	    	       // System.out.println(EndTime-StartTime);
	    	    int Clues	=81-Counter;
	    	        System.out.println( "Number of clues:  " +Clues ); 
	    	        System.out.println("\n");
	    	     //   BT.printGrid();
	    	      }
	    	      else{
	    	         System.out.println("No solution exists");}
	    	}
	    
	    }catch (SQLException e) {
            e.printStackTrace();
          
        }finally{
        	if (stmt != null){ 
        		
        		stmt.close(); 
        		
        	}
        }
	    
}
}


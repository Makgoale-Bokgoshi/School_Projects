import java.sql.*;
public class DBClass {
	private Connection con=null;
	 private PreparedStatement statement;
	    private ResultSet resultSet;
	 public Connection dbConnector(){
    try{
        Class.forName("org.sqlite.JDBC");
        //con= DriverManager.getConnection("jdbc:sqlite:"+ "/files1a/689181/workspace/Assignment/src/AAI.sqlite");
        con= DriverManager.getConnection("jdbc:sqlite:"+ System.getProperty("user.dir")+"/src/AAI.sqlite");
        
      //  System.out.println("Connection was successful"+ System.getProperty("user.dir"));
    }catch(Exception e){
        System.out.println("error connecting to database");
    }
    return con;
    
}

	 public String query(String stmt) throws SQLException {
	        closePrevious();
	        statement = con.prepareStatement(stmt);
	        String table = processResultSet(resultSet = statement.executeQuery());
	        return table;
	    }
	 
	    public String processResultSet(ResultSet rs) throws SQLException {
	        String temp = "";
	        ResultSetMetaData meta = (ResultSetMetaData) rs.getMetaData();
	        int size = meta.getColumnCount();
	        while (rs.next()) {
	            for (int i = 1; i <= size; i++) {
	                Object value = rs.getObject(i);
	                temp += " " + value;
	            }
	            temp += "\n";
	        }

	        return temp;
	    }
	    private void closePrevious() {
	        if (resultSet != null) {
	            try {
	                resultSet.close();
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	            resultSet = null;
	        }
	        if (statement != null) {
	            try {
	                statement.close();
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	            statement = null;
	        }
	    }
	    
	    public void disconnect() {
	        closePrevious();
	        try {
	            con.close();
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	        con = null;
	    }
}
